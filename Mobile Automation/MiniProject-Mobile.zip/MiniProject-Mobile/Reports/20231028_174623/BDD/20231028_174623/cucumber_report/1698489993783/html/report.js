$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/Angelin/Katalon Studio/MiniProject-Mobile/Include/features/mobile.feature");
formatter.feature({
  "name": "Mobile Shooping List App Feature",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "i have opened the shopping list application",
  "keyword": "Given "
});
formatter.match({
  "location": "mobile.openApp()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add an item to the list",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "name": "they tap the Add Item button",
  "keyword": "When "
});
formatter.match({
  "location": "mobile.clickAddItem()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they enter Cabbage as the item name",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.fillItemName()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they enter 1 as the quantity",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.fillItemQuantity()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they click the Add Item button",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.addItem()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the item Cabbage with a quantity of 1 should be added to the shopping list",
  "keyword": "Then "
});
formatter.match({
  "location": "mobile.checkAddedItem()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "i have opened the shopping list application",
  "keyword": "Given "
});
formatter.match({
  "location": "mobile.openApp()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add an empty item to the list",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag2"
    }
  ]
});
formatter.step({
  "name": "user tap the Add Item button",
  "keyword": "When "
});
formatter.match({
  "location": "mobile.tapAddItem()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they set the item name empty",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.fillItemNameEmpty()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they enter 0 as the quantity",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.fillItemQuantity0()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user click the Add Item button",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.addEmptyItem()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user will get error message informing user cant add empty items",
  "keyword": "Then "
});
formatter.match({
  "location": "mobile.errorMessageEmptyItems()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "i have opened the shopping list application",
  "keyword": "Given "
});
formatter.match({
  "location": "mobile.openApp()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add an empty item to the list",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag3"
    }
  ]
});
formatter.step({
  "name": "user is in the home screen",
  "keyword": "When "
});
formatter.match({
  "location": "mobile.homeLabel()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the user will see the Home Header text",
  "keyword": "Then "
});
formatter.match({
  "location": "mobile.welcomeLabel()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "i have opened the shopping list application",
  "keyword": "Given "
});
formatter.match({
  "location": "mobile.openApp()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Verify Item Quanntity Input Field Validation",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag4"
    }
  ]
});
formatter.step({
  "name": "user tap the Add Item button or plus icon",
  "keyword": "When "
});
formatter.match({
  "location": "mobile.userTapItemButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they enter an invalid negative quantity for a new item",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.userAddInvalidQuantity()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they tap the Add button",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.userTapAddButton1()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the application should display an error message indicating that the quantity is invalid",
  "keyword": "Then "
});
formatter.match({
  "location": "mobile.quantityErrorMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "i have opened the shopping list application",
  "keyword": "Given "
});
formatter.match({
  "location": "mobile.openApp()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Verify Reset Button in add form",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag5"
    }
  ]
});
formatter.step({
  "name": "user click the add + or button",
  "keyword": "When "
});
formatter.match({
  "location": "mobile.userClickAddButton2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they fill the credentials to add an item",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.userFillAddForm()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "they tap the Reset button",
  "keyword": "And "
});
formatter.match({
  "location": "mobile.userClickReset()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "the feature or functionality should be reset to its initial state",
  "keyword": "Then "
});
formatter.match({
  "location": "mobile.formIsReseted()"
});
formatter.result({
  "status": "passed"
});
});