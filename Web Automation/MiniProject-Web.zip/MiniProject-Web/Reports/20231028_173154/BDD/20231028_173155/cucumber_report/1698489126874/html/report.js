$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/Angelin/Katalon Studio/MiniProject-Web/Include/features/web.feature");
formatter.feature({
  "name": "Web",
  "description": "  I want to use this template for my feature file",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View Transaction History",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "name": "I am logged into my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLoggedin3()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I navigate to the Transaction History",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickTransaction()"
});
formatter.result({
  "error_message": "com.kms.katalon.core.exception.StepFailedException: Unable to click on object \u0027Object Repository/Profile/Profile button\u0027\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.stepFailed(WebUIKeywordMain.groovy:64)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.runKeyword(WebUIKeywordMain.groovy:26)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.click(ClickKeyword.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.execute(ClickKeyword.groovy:40)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordExecutor.executeKeywordForPlatform(KeywordExecutor.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords.click(WebUiBuiltInKeywords.groovy:620)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords$click$0.call(Unknown Source)\r\n\tat web.iClickTransaction(web.groovy:64)\r\n\tat ✽.I navigate to the Transaction History(C:/Users/Angelin/Katalon Studio/MiniProject-Web/Include/features/web.feature:29)\r\nCaused by: org.openqa.selenium.WebDriverException: disconnected: not connected to DevTools\n  (failed to check if window was closed: disconnected: not connected to DevTools)\n  (Session info: chrome\u003d118.0.5993.118)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:25:53\u0027\nSystem info: host: \u0027ANGELINE\u0027, ip: \u002710.10.1.177\u0027, os.name: \u0027Windows 11\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_362\u0027\nDriver info: com.kms.katalon.selenium.driver.CChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 118.0.5993.118, chrome: {chromedriverVersion: 118.0.5993.70 (e52f33f30b91..., userDataDir: C:\\Users\\Angelin\\AppData\\Lo...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:61593}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}\nSession ID: b77d11ea420bab97161ff93fecb77e46\n*** Element info: {Using\u003dxpath, value\u003d/html/body/div/div/header/div/button[2]}\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat com.kms.katalon.selenium.driver.CChromeDriver.execute(CChromeDriver.java:19)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElements(RemoteWebDriver.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementsByXPath(RemoteWebDriver.java:432)\r\n\tat org.openqa.selenium.By$ByXPath.findElements(By.java:348)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElements(RemoteWebDriver.java:311)\r\n\tat org.openqa.selenium.support.events.EventFiringWebDriver.lambda$new$1(EventFiringWebDriver.java:105)\r\n\tat com.sun.proxy.$Proxy17.findElements(Unknown Source)\r\n\tat org.openqa.selenium.support.events.EventFiringWebDriver.findElements(EventFiringWebDriver.java:182)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementByNormalMethods(WebUiCommonHelper.java:1027)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsBySelectedMethod(WebUiCommonHelper.java:919)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsBySelectedMethod(WebUiCommonHelper.java:901)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsBySelectedMethod(WebUiCommonHelper.java:896)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsByDefault(WebUiCommonHelper.java:892)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findWebElements(WebUiCommonHelper.java:720)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findWebElement(WebUiCommonHelper.java:1376)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword.findWebElement(WebUIAbstractKeyword.groovy:27)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword$_click_closure1.doCall(ClickKeyword.groovy:65)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword$_click_closure1.call(ClickKeyword.groovy)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.runKeyword(WebUIKeywordMain.groovy:20)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.click(ClickKeyword.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.execute(ClickKeyword.groovy:40)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordExecutor.executeKeywordForPlatform(KeywordExecutor.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords.click(WebUiBuiltInKeywords.groovy:620)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords$click$0.call(Unknown Source)\r\n\tat web.iClickTransaction(web.groovy:64)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:26)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:20)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:48)\r\n\tat cucumber.runtime.PickleStepDefinitionMatch.runStep(PickleStepDefinitionMatch.java:50)\r\n\tat cucumber.runner.TestStep.executeStep(TestStep.java:70)\r\n\tat cucumber.runner.TestStep.run(TestStep.java:52)\r\n\tat cucumber.runner.PickleStepTestStep.run(PickleStepTestStep.java:53)\r\n\tat cucumber.runner.TestCase.run(TestCase.java:47)\r\n\tat cucumber.runner.Runner.runPickle(Runner.java:44)\r\n\tat cucumber.runtime.Runtime.runFeature(Runtime.java:120)\r\n\tat cucumber.runtime.Runtime.run(Runtime.java:106)\r\n\tat cucumber.api.cli.Main.run(Main.java:35)\r\n\tat cucumber.api.cli.Main$run.call(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$_runFeatureFile_closure1.doCall(CucumberBuiltinKeywords.groovy:108)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$_runFeatureFile_closure1.doCall(CucumberBuiltinKeywords.groovy)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain.runKeyword(KeywordMain.groovy:75)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain.runKeyword(KeywordMain.groovy:69)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain$runKeyword.call(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords.runFeatureFile(CucumberBuiltinKeywords.groovy:75)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$runFeatureFile$0.callStatic(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords.runFeatureFile(CucumberBuiltinKeywords.groovy:248)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$runFeatureFile.call(Unknown Source)\r\n\tat BDD.run(BDD:20)\r\n\tat com.kms.katalon.core.main.ScriptEngine.run(ScriptEngine.java:194)\r\n\tat com.kms.katalon.core.main.ScriptEngine.runScriptAsRawText(ScriptEngine.java:119)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.runScript(TestCaseExecutor.java:448)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.doExecute(TestCaseExecutor.java:439)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.processExecutionPhase(TestCaseExecutor.java:418)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.accessMainPhase(TestCaseExecutor.java:410)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.execute(TestCaseExecutor.java:285)\r\n\tat com.kms.katalon.core.common.CommonExecutor.accessTestCaseMainPhase(CommonExecutor.java:65)\r\n\tat com.kms.katalon.core.main.TestSuiteExecutor.accessTestSuiteMainPhase(TestSuiteExecutor.java:148)\r\n\tat com.kms.katalon.core.main.TestSuiteExecutor.execute(TestSuiteExecutor.java:106)\r\n\tat com.kms.katalon.core.main.TestCaseMain.startTestSuite(TestCaseMain.java:187)\r\n\tat com.kms.katalon.core.main.TestCaseMain$startTestSuite$0.call(Unknown Source)\r\n\tat TempTestSuite1698489115965.run(TempTestSuite1698489115965.groovy:36)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "I should see a list of my previous transactions",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSeeTransactionHistory()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View product details",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag2"
    }
  ]
});
formatter.step({
  "name": "I click on the product to view its details",
  "keyword": "When "
});
formatter.match({
  "location": "web.iSelectProductDetail()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product detail page should open with accurate product information",
  "keyword": "Then "
});
formatter.match({
  "location": "web.viewDetailProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Checkout items on cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag3"
    }
  ]
});
formatter.step({
  "name": "I login to my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the product Beli button to add to cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickBeli()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Checkout button",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickCheckout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should get success notification",
  "keyword": "Then "
});
formatter.match({
  "location": "web.getSuccessCheckoutNotif()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Checkout items on cart without login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag4"
    }
  ]
});
formatter.step({
  "name": "I add a product to the shopping cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iAddProduct()"
});
formatter.result({
  "error_message": "com.kms.katalon.core.exception.StepFailedException: Unable to click on object \u0027Object Repository/Product/Beli Button\u0027\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.stepFailed(WebUIKeywordMain.groovy:64)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.runKeyword(WebUIKeywordMain.groovy:26)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.click(ClickKeyword.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.execute(ClickKeyword.groovy:40)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordExecutor.executeKeywordForPlatform(KeywordExecutor.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords.click(WebUiBuiltInKeywords.groovy:620)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords$click$0.call(Unknown Source)\r\n\tat web.iAddProduct(web.groovy:134)\r\n\tat ✽.I add a product to the shopping cart(C:/Users/Angelin/Katalon Studio/MiniProject-Web/Include/features/web.feature:46)\r\nCaused by: org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d118.0.5993.118)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:25:53\u0027\nSystem info: host: \u0027ANGELINE\u0027, ip: \u002710.10.1.177\u0027, os.name: \u0027Windows 11\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_362\u0027\nDriver info: com.kms.katalon.selenium.driver.CChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 118.0.5993.118, chrome: {chromedriverVersion: 118.0.5993.70 (e52f33f30b91..., userDataDir: C:\\Users\\Angelin\\AppData\\Lo...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:61670}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}\nSession ID: f0015f3b01e890ab992db1b196991b36\n*** Element info: {Using\u003dxpath, value\u003d/html/body/div/div/main/div/div/div[2]/div/div[1]/div/div[3]/div[2]/button[2]}\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat com.kms.katalon.selenium.driver.CChromeDriver.execute(CChromeDriver.java:19)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElements(RemoteWebDriver.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementsByXPath(RemoteWebDriver.java:432)\r\n\tat org.openqa.selenium.By$ByXPath.findElements(By.java:348)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElements(RemoteWebDriver.java:311)\r\n\tat org.openqa.selenium.support.events.EventFiringWebDriver.lambda$new$1(EventFiringWebDriver.java:105)\r\n\tat com.sun.proxy.$Proxy17.findElements(Unknown Source)\r\n\tat org.openqa.selenium.support.events.EventFiringWebDriver.findElements(EventFiringWebDriver.java:182)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementByNormalMethods(WebUiCommonHelper.java:1027)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsBySelectedMethod(WebUiCommonHelper.java:919)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsBySelectedMethod(WebUiCommonHelper.java:901)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsBySelectedMethod(WebUiCommonHelper.java:896)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findElementsByDefault(WebUiCommonHelper.java:892)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findWebElements(WebUiCommonHelper.java:720)\r\n\tat com.kms.katalon.core.webui.common.WebUiCommonHelper.findWebElement(WebUiCommonHelper.java:1376)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword.findWebElement(WebUIAbstractKeyword.groovy:27)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword$_click_closure1.doCall(ClickKeyword.groovy:65)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword$_click_closure1.call(ClickKeyword.groovy)\r\n\tat com.kms.katalon.core.webui.keyword.internal.WebUIKeywordMain.runKeyword(WebUIKeywordMain.groovy:20)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.click(ClickKeyword.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.builtin.ClickKeyword.execute(ClickKeyword.groovy:40)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordExecutor.executeKeywordForPlatform(KeywordExecutor.groovy:74)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords.click(WebUiBuiltInKeywords.groovy:620)\r\n\tat com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords$click$0.call(Unknown Source)\r\n\tat web.iAddProduct(web.groovy:134)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:26)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:20)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:48)\r\n\tat cucumber.runtime.PickleStepDefinitionMatch.runStep(PickleStepDefinitionMatch.java:50)\r\n\tat cucumber.runner.TestStep.executeStep(TestStep.java:70)\r\n\tat cucumber.runner.TestStep.run(TestStep.java:52)\r\n\tat cucumber.runner.PickleStepTestStep.run(PickleStepTestStep.java:53)\r\n\tat cucumber.runner.TestCase.run(TestCase.java:47)\r\n\tat cucumber.runner.Runner.runPickle(Runner.java:44)\r\n\tat cucumber.runtime.Runtime.runFeature(Runtime.java:120)\r\n\tat cucumber.runtime.Runtime.run(Runtime.java:106)\r\n\tat cucumber.api.cli.Main.run(Main.java:35)\r\n\tat cucumber.api.cli.Main$run.call(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$_runFeatureFile_closure1.doCall(CucumberBuiltinKeywords.groovy:108)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$_runFeatureFile_closure1.doCall(CucumberBuiltinKeywords.groovy)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain.runKeyword(KeywordMain.groovy:75)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain.runKeyword(KeywordMain.groovy:69)\r\n\tat com.kms.katalon.core.keyword.internal.KeywordMain$runKeyword.call(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords.runFeatureFile(CucumberBuiltinKeywords.groovy:75)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$runFeatureFile$0.callStatic(Unknown Source)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords.runFeatureFile(CucumberBuiltinKeywords.groovy:248)\r\n\tat com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords$runFeatureFile.call(Unknown Source)\r\n\tat BDD.run(BDD:20)\r\n\tat com.kms.katalon.core.main.ScriptEngine.run(ScriptEngine.java:194)\r\n\tat com.kms.katalon.core.main.ScriptEngine.runScriptAsRawText(ScriptEngine.java:119)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.runScript(TestCaseExecutor.java:448)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.doExecute(TestCaseExecutor.java:439)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.processExecutionPhase(TestCaseExecutor.java:418)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.accessMainPhase(TestCaseExecutor.java:410)\r\n\tat com.kms.katalon.core.main.TestCaseExecutor.execute(TestCaseExecutor.java:285)\r\n\tat com.kms.katalon.core.common.CommonExecutor.accessTestCaseMainPhase(CommonExecutor.java:65)\r\n\tat com.kms.katalon.core.main.TestSuiteExecutor.accessTestSuiteMainPhase(TestSuiteExecutor.java:148)\r\n\tat com.kms.katalon.core.main.TestSuiteExecutor.execute(TestSuiteExecutor.java:106)\r\n\tat com.kms.katalon.core.main.TestCaseMain.startTestSuite(TestCaseMain.java:187)\r\n\tat com.kms.katalon.core.main.TestCaseMain$startTestSuite$0.call(Unknown Source)\r\n\tat TempTestSuite1698489115965.run(TempTestSuite1698489115965.groovy:36)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "I proceed to checkout",
  "keyword": "And "
});
formatter.match({
  "location": "web.iCheckout()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "I should be prompted to log in or continue as a guest",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iRediresctToLogin()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Invalid login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag5"
    }
  ]
});
formatter.step({
  "name": "I click the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter invalid login credentials",
  "keyword": "And "
});
formatter.match({
  "location": "web.iEnterInvalidLoginCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Login button to login",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLoginToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should receive an error message indicating invalid credentials",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iGetErrorLoginMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Valid Login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag6"
    }
  ]
});
formatter.step({
  "name": "I tap the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickLogin2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter valid login credentials",
  "keyword": "And "
});
formatter.match({
  "location": "web.iEnterValidLoginCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I tap the Login button to login to my account",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLoginToLogin2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should successfully log into my account",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSuccesfullyLoginToMyAccount()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Invalid Register",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag7"
    }
  ]
});
formatter.step({
  "name": "I navigate to the registration page",
  "keyword": "When "
});
formatter.match({
  "location": "web.iNavigateRegister()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I submit the registration form without filling in any fields",
  "keyword": "And "
});
formatter.match({
  "location": "web.iSubmitEmptyRegistrationForm()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see validation errors indicating that all fields are required",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iGetErrorRegisterMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Valid Register",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag8"
    }
  ]
});
formatter.step({
  "name": "I click the Register button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickTheRegisterButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I fill in the required registration details",
  "keyword": "And "
});
formatter.match({
  "location": "web.iFillValidRgister()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Register button2",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickRegis2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be successfully registered as a new user",
  "keyword": "Then "
});
formatter.match({
  "location": "web.successRegister()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Remove items from cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag9"
    }
  ]
});
formatter.step({
  "name": "I add items to shopping cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iAddItems()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I open my cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.openMyCart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I remove the product from my cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.removeProductFromCart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product should be removed from the shopping cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.productIsRemoved()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Search a product",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag10"
    }
  ]
});
formatter.step({
  "name": "I click the search box",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickSearch()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I choose the selection in the dropdown",
  "keyword": "And "
});
formatter.match({
  "location": "web.iChooseSearchOption()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Search results matching the keyword should appear",
  "keyword": "Then "
});
formatter.match({
  "location": "web.getSearchResults()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Update quantity of product",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag11"
    }
  ]
});
formatter.step({
  "name": "I click on the shopping cart icon to view its contents",
  "keyword": "When "
});
formatter.match({
  "location": "web.iOpenMyCart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I change the quantity of items for a product in the cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.iChangeQuantity()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The quantity of items in the cart should be updated correctly",
  "keyword": "Then "
});
formatter.match({
  "location": "web.quantityIsUpdated()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User can logout",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag12"
    }
  ]
});
formatter.step({
  "name": "i log in to my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLogIn()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i click profile button",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickProfile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i click logout",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLogout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i will redirect to login page",
  "keyword": "Then "
});
formatter.match({
  "location": "web.redirectToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View shopping cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag13"
    }
  ]
});
formatter.step({
  "name": "i click Beli Button to add items to cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickBeliAndAddItems()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i open my cart page",
  "keyword": "And "
});
formatter.match({
  "location": "web.iOpenMyCartPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i can see all my items on cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSeeAllMyItems()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add to cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag14"
    }
  ]
});
formatter.step({
  "name": "I click the Beli button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iSelectProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product should be successfully added to my shopping cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.addProductTo()"
});
formatter.result({
  "status": "passed"
});
});