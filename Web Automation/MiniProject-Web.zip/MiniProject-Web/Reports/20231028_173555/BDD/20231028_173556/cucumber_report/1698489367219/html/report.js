$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/Angelin/Katalon Studio/MiniProject-Web/Include/features/web.feature");
formatter.feature({
  "name": "Web",
  "description": "  I want to use this template for my feature file",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View Transaction History",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "name": "I am logged into my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLoggedin3()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I navigate to the Transaction History",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickTransaction()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see a list of my previous transactions",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSeeTransactionHistory()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View product details",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag2"
    }
  ]
});
formatter.step({
  "name": "I click on the product to view its details",
  "keyword": "When "
});
formatter.match({
  "location": "web.iSelectProductDetail()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product detail page should open with accurate product information",
  "keyword": "Then "
});
formatter.match({
  "location": "web.viewDetailProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Checkout items on cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag3"
    }
  ]
});
formatter.step({
  "name": "I login to my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the product Beli button to add to cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickBeli()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Checkout button",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickCheckout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should get success notification",
  "keyword": "Then "
});
formatter.match({
  "location": "web.getSuccessCheckoutNotif()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Checkout items on cart without login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag4"
    }
  ]
});
formatter.step({
  "name": "I add a product to the shopping cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iAddProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I proceed to checkout",
  "keyword": "And "
});
formatter.match({
  "location": "web.iCheckout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be prompted to log in or continue as a guest",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iRediresctToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Invalid login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag5"
    }
  ]
});
formatter.step({
  "name": "I click the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter invalid login credentials",
  "keyword": "And "
});
formatter.match({
  "location": "web.iEnterInvalidLoginCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Login button to login",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLoginToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should receive an error message indicating invalid credentials",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iGetErrorLoginMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Valid Login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag6"
    }
  ]
});
formatter.step({
  "name": "I tap the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickLogin2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter valid login credentials",
  "keyword": "And "
});
formatter.match({
  "location": "web.iEnterValidLoginCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I tap the Login button to login to my account",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLoginToLogin2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should successfully log into my account",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSuccesfullyLoginToMyAccount()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Invalid Register",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag7"
    }
  ]
});
formatter.step({
  "name": "I navigate to the registration page",
  "keyword": "When "
});
formatter.match({
  "location": "web.iNavigateRegister()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I submit the registration form without filling in any fields",
  "keyword": "And "
});
formatter.match({
  "location": "web.iSubmitEmptyRegistrationForm()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see validation errors indicating that all fields are required",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iGetErrorRegisterMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Valid Register",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag8"
    }
  ]
});
formatter.step({
  "name": "I click the Register button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickTheRegisterButton()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I fill in the required registration details",
  "keyword": "And "
});
formatter.match({
  "location": "web.iFillValidRgister()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Register button2",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickRegis2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be successfully registered as a new user",
  "keyword": "Then "
});
formatter.match({
  "location": "web.successRegister()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Remove items from cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag9"
    }
  ]
});
formatter.step({
  "name": "I add items to shopping cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iAddItems()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I open my cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.openMyCart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I remove the product from my cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.removeProductFromCart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product should be removed from the shopping cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.productIsRemoved()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Search a product",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag10"
    }
  ]
});
formatter.step({
  "name": "I click the search box",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickSearch()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I choose the selection in the dropdown",
  "keyword": "And "
});
formatter.match({
  "location": "web.iChooseSearchOption()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Search results matching the keyword should appear",
  "keyword": "Then "
});
formatter.match({
  "location": "web.getSearchResults()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Update quantity of product",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag11"
    }
  ]
});
formatter.step({
  "name": "I click on the shopping cart icon to view its contents",
  "keyword": "When "
});
formatter.match({
  "location": "web.iOpenMyCart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I change the quantity of items for a product in the cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.iChangeQuantity()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The quantity of items in the cart should be updated correctly",
  "keyword": "Then "
});
formatter.match({
  "location": "web.quantityIsUpdated()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "User can logout",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag12"
    }
  ]
});
formatter.step({
  "name": "i log in to my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLogIn()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i click profile button",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickProfile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i click logout",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLogout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i will redirect to login page",
  "keyword": "Then "
});
formatter.match({
  "location": "web.redirectToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View shopping cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag13"
    }
  ]
});
formatter.step({
  "name": "i click Beli Button to add items to cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickBeliAndAddItems()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i open my cart page",
  "keyword": "And "
});
formatter.match({
  "location": "web.iOpenMyCartPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "i can see all my items on cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSeeAllMyItems()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add to cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag14"
    }
  ]
});
formatter.step({
  "name": "I click the Beli button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iSelectProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product should be successfully added to my shopping cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.addProductTo()"
});
formatter.result({
  "status": "passed"
});
});