$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/Angelin/Katalon Studio/MiniProject-Web/Include/features/web.feature");
formatter.feature({
  "name": "Web",
  "description": "  I want to use this template for my feature file",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Add to cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag14"
    }
  ]
});
formatter.step({
  "name": "I click the Beli button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iSelectProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product should be successfully added to my shopping cart",
  "keyword": "Then "
});
formatter.match({
  "location": "web.addProductTo()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "View product details",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag2"
    }
  ]
});
formatter.step({
  "name": "I click on the product to view its details",
  "keyword": "When "
});
formatter.match({
  "location": "web.iSelectProductDetail()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "The product detail page should open with accurate product information",
  "keyword": "Then "
});
formatter.match({
  "location": "web.viewDetailProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Checkout items on cart",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag3"
    }
  ]
});
formatter.step({
  "name": "I login to my account",
  "keyword": "When "
});
formatter.match({
  "location": "web.iLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the product Beli button to add to cart",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickBeli()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Checkout button",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickCheckout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should get success notification",
  "keyword": "Then "
});
formatter.match({
  "location": "web.getSuccessCheckoutNotif()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Checkout items on cart without login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag4"
    }
  ]
});
formatter.step({
  "name": "I add a product to the shopping cart",
  "keyword": "When "
});
formatter.match({
  "location": "web.iAddProduct()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I proceed to checkout",
  "keyword": "And "
});
formatter.match({
  "location": "web.iCheckout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be prompted to log in or continue as a guest",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iRediresctToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Invalid login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag5"
    }
  ]
});
formatter.step({
  "name": "I click the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter invalid login credentials",
  "keyword": "And "
});
formatter.match({
  "location": "web.iEnterInvalidLoginCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click the Login button to login",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLoginToLogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should receive an error message indicating invalid credentials",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iGetErrorLoginMessage()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I am on the Alta Shop website",
  "keyword": "Given "
});
formatter.match({
  "location": "web.onTheWebsite()"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Valid Login",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    },
    {
      "name": "@tag6"
    }
  ]
});
formatter.step({
  "name": "I tap the Login button",
  "keyword": "When "
});
formatter.match({
  "location": "web.iClickLogin2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter valid login credentials",
  "keyword": "And "
});
formatter.match({
  "location": "web.iEnterValidLoginCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I tap the Login button to login to my account",
  "keyword": "And "
});
formatter.match({
  "location": "web.iClickLoginToLogin2()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should successfully log into my account",
  "keyword": "Then "
});
formatter.match({
  "location": "web.iSuccesfullyLoginToMyAccount()"
});
