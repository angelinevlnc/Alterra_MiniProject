import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class web {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */
	
	@Given("I am on the Alta Shop website")
	def onTheWebsite() {
		WebUI.openBrowser('https://alta-shop.vercel.app/')
	}
	
	
	//view transaction
	
	@When("I am logged into my account")
	def iLoggedin3() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))
		
		WebUI.setText(findTestObject('Authentication/LoginField_Email'), 'abc@gmail.com')
		
		WebUI.setText(findTestObject('Authentication/LoginField_Password'), 'abc')
		
		WebUI.click(findTestObject('Authentication/Login Button'))
	}
	@And("I navigate to the Transaction History")
	def iClickTransaction() {
		WebUI.click(findTestObject('Profile/Profile button'))
		WebUI.click(findTestObject('Profile/Transaksi Button'))
	}
	@Then("I should see a list of my previous transactions")
	def iSeeTransactionHistory() {
		WebUI.verifyElementVisible(findTestObject('Profile/Transactions Page'))
	}
	
	
	
	//beli
	@When("I click the Beli button")
	def iSelectProduct() {
		WebUI.click(findTestObject('Product/Beli Button'))
	}
	

	@Then("The product should be successfully added to my shopping cart")
	def addProductTo() {
		WebUI.verifyElementVisible(findTestObject('Product/Cart_1'))
	}
	
	//detail
	@When("I click on the product to view its details")
	def iSelectProductDetail() {
		WebUI.click(findTestObject('Product/Detail button'))
	}
	

	@Then("The product detail page should open with accurate product information")
	def viewDetailProduct() {
		WebUI.verifyElementVisible(findTestObject('Product/Card Details'))
	}
	
	//checkout items on cart
	@When("I login to my account")
	def iLogin() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))
		
		WebUI.setText(findTestObject('Authentication/LoginField_Email'), 'abc@gmail.com')
		
		WebUI.setText(findTestObject('Authentication/LoginField_Password'), 'abc')
		
		WebUI.click(findTestObject('Authentication/Login Button'))
	}
	
	@And("I click on the product Beli button to add to cart")
	def iClickBeli() {
		WebUI.click(findTestObject('Product/Beli Button'))
		WebUI.click(findTestObject('Cart/Cart button'))
	}
	
	
	@And("I click the Checkout button")
	def iClickCheckout() {
		WebUI.click(findTestObject('Cart/Bayar Button'))
	}

	@Then("I should get success notification")
	def getSuccessCheckoutNotif() {
		WebUI.verifyElementVisible(findTestObject('Cart/Success checkout'))
	}
	
	//checkout without login
	@When("I add a product to the shopping cart")
	def iAddProduct() {
		WebUI.click(findTestObject('Product/Beli Button'))
	}
	@And("I proceed to checkout")
	def iCheckout() {
		WebUI.click(findTestObject('Cart/Cart button'))
		WebUI.click(findTestObject('Cart/Bayar Button'))
	}
	@Then("I should be prompted to log in or continue as a guest")
	def iRediresctToLogin() {
		WebUI.verifyElementVisible(findTestObject('Cart/Checkout wihput login'))
	}
	
	
	//invalid login
	@When("I click the Login button")
	def iClickLogin() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))
	}
	@And("I enter invalid login credentials")
	def iEnterInvalidLoginCredentials() {
		WebUI.setText(findTestObject('Authentication/LoginField_Email'), 'angelinev@gmail.com')
		
		WebUI.setText(findTestObject('Authentication/LoginField_Password'), 'angelinev')
	}
	@And("I click the Login button to login")
	def iClickLoginToLogin() {
		WebUI.click(findTestObject('Authentication/Login Button'))
	}
	@Then("I should receive an error message indicating invalid credentials")
	def iGetErrorLoginMessage() {
		WebUI.verifyElementVisible(findTestObject('Authentication/Login Error Message_Record not found'))
	}
	//valid login
	@When("I tap the Login button")
	def iClickLogin2() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))
	}
	@And("I enter valid login credentials")
	def iEnterValidLoginCredentials() {
		WebUI.setText(findTestObject('Authentication/LoginField_Email'), 'abc@gmail.com')

		WebUI.setText(findTestObject('Authentication/LoginField_Password'), 'abc')
	}
	@And("I tap the Login button to login to my account")
	def iClickLoginToLogin2() {
		WebUI.click(findTestObject('Authentication/Login Button'))
	}
	@Then("I should successfully log into my account")
	def iSuccesfullyLoginToMyAccount() {
		WebUI.verifyElementVisible(findTestObject('Profile/Profile button'))
	}
	
	//register invalid
	@When("I navigate to the registration page")
	def iNavigateRegister() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))

		WebUI.click(findTestObject('Authentication/a_Register Button'))
	}
	@And("I submit the registration form without filling in any fields")
	def iSubmitEmptyRegistrationForm() {
		WebUI.setText(findTestObject('Authentication/RegisterField_Nama'), '')

		WebUI.setText(findTestObject('Authentication/RegisterField_Email'), '')
		
		WebUI.setText(findTestObject('Authentication/RegisterField_Password'), '')
		WebUI.click(findTestObject('Authentication/Register Button'))
	}
	@Then("I should see validation errors indicating that all fields are required")
	def iGetErrorRegisterMessage() {
		WebUI.verifyElementPresent(findTestObject('Authentication/Register Error Message'), 0)
	}
	
	//remove items from cart
	@When("I add items to shopping cart")
	def iAddItems() {
		WebUI.click(findTestObject('Product/Beli Button'))
	}
	@And("I open my cart")
	def openMyCart() {
		WebUI.click(findTestObject('Cart/Cart button'))
	}
	@And("I remove the product from my cart")
	def removeProductFromCart() {
		WebUI.click(findTestObject('Cart/Button -'))
	}
	@Then("The product should be removed from the shopping cart")
	def productIsRemoved() {
		WebUI.verifyElementVisible(findTestObject('Cart/Empty Cart Message'))
	}
	
	//search
	@When("I click the search box")
	def iClickSearch() {
		WebUI.click(findTestObject('Product/Category Option'))
	}
	@And("I choose the selection in the dropdown")
	def iChooseSearchOption() {
		WebUI.click(findTestObject('Product/Category button'))
	}
	@Then("Search results matching the keyword should appear")
	def getSearchResults() {
		WebUI.verifyElementVisible(findTestObject('Product/SearchPage'))
	}
	
	//update quantity
	@When("I click on the shopping cart icon to view its contents")
	def iOpenMyCart() {
		WebUI.click(findTestObject('Product/Beli Button'))

		WebUI.click(findTestObject('Cart/Cart button'))
	}
	@And("I change the quantity of items for a product in the cart")
	def iChangeQuantity() {
		WebUI.click(findTestObject('Cart/ButtonPlus'))
	}
	@Then("The quantity of items in the cart should be updated correctly")
	def quantityIsUpdated() {
		WebUI.verifyElementVisible(findTestObject('Cart/Quantity2'))
	}
	
	//user can logout
	@When("i log in to my account")
	def iLogIn() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))

		WebUI.setText(findTestObject('Authentication/LoginField_Email'), 'abc@gmail.com')
		
		WebUI.setText(findTestObject('Authentication/LoginField_Password'), 'abc')
		
		WebUI.click(findTestObject('Authentication/Login Button'))
	}
	@And("i click profile button")
	def iClickProfile() {
		WebUI.click(findTestObject('Profile/Profile button'))
	}
	@And("i click logout")
	def iClickLogout() {
		WebUI.click(findTestObject('Profile/Logout button'))
	}
	@Then("i will redirect to login page")
	def redirectToLogin() {
		WebUI.verifyElementVisible(findTestObject('Authentication/LoginPage'))
	}
	
	//view shopping
	@When("i click Beli Button to add items to cart")
	def iClickBeliAndAddItems() {
		WebUI.click(findTestObject('Product/Beli Button'))
	}
	@And("i open my cart page")
	def iOpenMyCartPage() {
		WebUI.click(findTestObject('Cart/Cart button'))
	}
	@Then("i can see all my items on cart")
	def iSeeAllMyItems() {
		WebUI.verifyElementVisible(findTestObject('Cart/Cart Items'))
	}
	
	
	//register valid
	@When("I click the Register button")
	def iClickTheRegisterButton() {
		WebUI.click(findTestObject('Authentication/Nav Login button'))
		
		WebUI.click(findTestObject('Authentication/a_Register Button'))
	}
	@And("I fill in the required registration details")
	def iFillValidRgister(){
		WebUI.setText(findTestObject('Authentication/RegisterField_Nama'), 'cba')
		
		WebUI.setText(findTestObject('Authentication/RegisterField_Email'), 'cba@gmail.com')
		
		WebUI.setText(findTestObject('Authentication/RegisterField_Password'), 'cba')
	}
	@And("I click the Register button2")
	def iClickRegis2() {
		WebUI.click(findTestObject('Authentication/Register Button'))
	}
	@Then("I should be successfully registered as a new user")
	def successRegister() {
		WebUI.verifyElementPresent(findTestObject('Authentication/LoginPage'), 0)
	}
	
	
	
}